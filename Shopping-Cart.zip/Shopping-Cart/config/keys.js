module.exports = {
  MONGO_URL: process.env.MONGO_URL 
};